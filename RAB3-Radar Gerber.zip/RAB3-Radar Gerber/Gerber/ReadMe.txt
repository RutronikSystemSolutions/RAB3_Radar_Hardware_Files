
Project RAB3-Radar Rev1:
PCB dimensions 50x52.98mm.
4 Layers.
Thickness: 1.55mm FR4.
Mask color: Purple.
Silkscreen color: White.
Finish: Immersion Gold.
Vias: Tented. 